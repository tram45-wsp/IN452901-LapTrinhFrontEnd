// Câu 2: viết JavaScript tại đây

const API_URL = 'http://localhost:4000';

// Hàm có sẵn: đổi giờ UTC sang giờ Việt Nam, vd "08:00 12/09/2026"
const formatDateTime = (iso) =>
  new Date(iso).toLocaleString('vi-VN', {
    timeZone: 'Asia/Ho_Chi_Minh',
    hour: '2-digit', minute: '2-digit',
    day: '2-digit', month: '2-digit', year: 'numeric',
  });

  // Câu 2a: Hàm formatSeats
const formatSeats = (event) => {
    const remaining = event.capacity - event.registeredCount;
    if (remaining <= 0) {
        return "Hết chỗ";
    }
    return `Còn ${remaining}/${event.capacity} chỗ`;
};

// Câu 2b: Hàm renderEvents
const renderEvents = (events) => {
    const eventList = document.getElementById('event-list');
    
    const cards = events.map(event => {
        const article = document.createElement('article');
        article.className = 'event-card';

        const img = document.createElement('img');
        img.src = 'img/event.svg';
        img.alt = event.name;

        const contentDiv = document.createElement('div');
        contentDiv.className = 'event-content';

        const h3 = document.createElement('h3');
        const a = document.createElement('a');
        a.href = `event-detail.html?id=${event.id}`;
        a.textContent = event.name;
        h3.appendChild(a);

        const pTime = document.createElement('p');
        const time = document.createElement('time');
        time.setAttribute('datetime', event.startTime);
        time.textContent = formatDateTime(event.startTime);
        pTime.appendChild(time);

        const pLocation = document.createElement('p');
        pLocation.textContent = event.location;

        const pSeats = document.createElement('p');
        const seatText = formatSeats(event);
        if (seatText === 'Hết chỗ') {
            const spanBadge = document.createElement('span');
            spanBadge.className = 'badge-danger';
            spanBadge.textContent = seatText;
            pSeats.appendChild(spanBadge);
        } else {
            pSeats.className = 'seats';
            pSeats.textContent = seatText;
        }

        contentDiv.appendChild(h3);
        contentDiv.appendChild(pTime);
        contentDiv.appendChild(pLocation);
        contentDiv.appendChild(pSeats);

        article.appendChild(img);
        article.appendChild(contentDiv);

        return article;
    });

    eventList.replaceChildren(...cards);
};

// Câu 2c: Hàm loadEvents bất đồng bộ
const loadEvents = async (keyword = '') => {
    const statusEl = document.getElementById('status');
    const eventList = document.getElementById('event-list');

    // Hiển thị trạng thái đang tải
    statusEl.textContent = 'Đang tải...';

    try {
        const params = new URLSearchParams({ pageSize: 50 });
        const trimmedKeyword = keyword.trim();
        if (trimmedKeyword !== '') {
            params.append('q', trimmedKeyword);
        }

        const response = await fetch(`${API_URL}/api/events?${params.toString()}`);
        
        // Kiểm tra lỗi máy chủ / mất kết nối
        if (!response.ok) {
            throw new Error('Lỗi máy chủ');
        }

        const data = await response.json();
        const items = data.items || [];

        if (items.length === 0) {
            statusEl.textContent = 'Không có sự kiện nào khớp từ khoá.';
            eventList.replaceChildren(); // Xóa danh sách cũ nếu không tìm thấy
        } else {
            statusEl.textContent = `Tìm thấy ${items.length} sự kiện`;
            renderEvents(items);
        }
    } catch (error) {
        statusEl.textContent = 'Không tải được dữ liệu, vui lòng thử lại.';
        eventList.replaceChildren();
    }
};

// Xử lý sự kiện khi submit form tìm kiếm và khởi chạy lúc mở trang
document.addEventListener('DOMContentLoaded', () => {
    const searchForm = document.getElementById('search-form');
    const keywordInput = document.getElementById('keyword');

    // Gọi tải danh sách ban đầu khi mở trang
    loadEvents();

    // Lắng nghe sự kiện gửi form tìm kiếm
    searchForm.addEventListener('submit', (e) => {
        e.preventDefault(); // Chặn tải lại trang
        const keyword = keywordInput.value;
        loadEvents(keyword);
    });
});